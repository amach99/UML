package android.example.hw4_phase2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WeatherPage extends MainActivity {

//    private TextView mDisplayText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weather_page);

        final Button backToMain = findViewById(R.id.weather_backButton);
        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainPage();
            }
        });

        final Button currentWeatherButton = findViewById(R.id.question2a);
        currentWeatherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCurrentLoc();
            }
        });

        final Button indiaWeatherButton = findViewById(R.id.question2BandC);
        indiaWeatherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openIndiaWeather();
            }
        });

        final Button homeTownWeatherButton = findViewById(R.id.question2d);
        homeTownWeatherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHometownWeather();
            }
        });
    }

    private void openHometownWeather() {
        String url = "https://www.google.com/search?q=weather+in+acton+ma&oq=weather+in+&aqs=chrome.0.69i59j69i57j69i59.1371j0j1&sourceid=chrome&ie=UTF-8";
        Intent weatherIntent = new Intent(Intent.ACTION_VIEW);
        weatherIntent.setData(Uri.parse(url));
        startActivity(weatherIntent);
    }

    private void openIndiaWeather() {
        String url = "https://www.google.com/search?ei=qwmmX4rjJJjSytMP8qSVuA4&q=weather+in+karimnagar&oq=weather+in+karminnag&gs_lcp=CgZwc3ktYWIQARgAMgwIABDJAxANEEYQgAIyBAgAEA0yBAgAEA0yBAgAEA0yBAgAEA0yBggAEA0QHjIGCAAQDRAeMgYIABANEB4yBggAEA0QHjIGCAAQDRAeOgQIABBHOgUIABDJAzoCCAA6CggAEMkDEEYQgAI6DQgAEMkDEJECEEYQgAI6BQgAEJECOgUIABCxAzoICAAQsQMQgwE6CAgAELEDEMkDOgQIABAKOgcIABDJAxAKOgUIIRCgAVDrrwFY2MYBYMbTAWgAcAJ4AIABswGIAckIkgEEMTYuMZgBAKABAaoBB2d3cy13aXrIAQjAAQE&sclient=psy-ab";
        Intent weatherIntent = new Intent(Intent.ACTION_VIEW);
        weatherIntent.setData(Uri.parse(url));
        startActivity(weatherIntent);
    }

    private void openCurrentLoc() {
        String url = "https://www.google.com/search?ei=yAmmX6X5AYGpytMPqeGUoA4&q=weather+in+lowell+ma&oq=weather+in+lowell+ma&gs_lcp=CgZwc3ktYWIQAzIKCAAQyQMQRhCAAjICCAAyAggAMgIIADICCAAyAggAMgIIADICCAA6BAgAEEc6BAgAEEM6CggAELEDEIMBEEM6BwgAELEDEEM6BQgAELEDOgkIABBDEEYQgAI6DQgAELEDEIMBEEYQgAI6BQgAEJECOggIABCxAxCDAToICAAQyQMQkQI6BQgAEMkDOgQIABAKOgkIABDJAxAWEB46BggAEBYQHlCZoAFY_boBYPq7AWgBcAJ4AIABTogBqAqSAQIyMZgBAKABAaoBB2d3cy13aXrIAQjAAQE&sclient=psy-ab&ved=0ahUKEwil_YHWtO_sAhWBlHIEHakwBeQQ4dUDCA0&uact=5";
        Intent weatherIntent = new Intent(Intent.ACTION_VIEW);
        weatherIntent.setData(Uri.parse(url));
        startActivity(weatherIntent);
    }

    private void openMainPage() {
        Intent mainPage= new Intent(this, MainActivity.class);
        startActivity(mainPage);
    }

}