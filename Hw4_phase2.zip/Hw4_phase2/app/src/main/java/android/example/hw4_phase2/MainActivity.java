package android.example.hw4_phase2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button weatherInfo = findViewById(R.id.weatherButton);
        weatherInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openWeatherPage();
            }
        });

        final Button aboutMeInfo = findViewById(R.id.aboutMeButton);
        aboutMeInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAboutMePage();
            }
        });

        final Button portfolioInfo = findViewById(R.id.portfolioButton);
        portfolioInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPortfolioPage();
            }
        });
    }

    private void openWeatherPage() {
        Intent weatherIntent = new Intent(MainActivity.this, WeatherPage.class);
        startActivity(weatherIntent);
    }

    private void openAboutMePage() {
        Intent aboutMeIntent = new Intent(MainActivity.this, AboutMePage.class);
        startActivity(aboutMeIntent);
    }

    private void openPortfolioPage() {
        Intent portfolioIntent = new Intent(MainActivity.this, PortfolioPage.class);
        startActivity(portfolioIntent);
    }


}