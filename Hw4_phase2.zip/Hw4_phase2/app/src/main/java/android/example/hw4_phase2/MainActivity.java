package android.example.hw4_phase2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weather_page);

        final Button weatherInfo = findViewById(R.id.weather_page);
        weatherInfo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openWeatherPage();
            }
        });
    }

    private void openWeatherPage() {
        Intent weatherInfo = new Intent(this, WeatherPage.class);
        startActivity(weatherInfo);
    }
}