package android.example.hw4_phase2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AboutMePage extends MainActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_me_page);

        final Button backToMain = findViewById(R.id.aboutMe_backButton);
        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainPage();
            }
        });

    }

    private void openMainPage() {
        Intent mainPage= new Intent(this, MainActivity.class);
        startActivity(mainPage);
    }

}