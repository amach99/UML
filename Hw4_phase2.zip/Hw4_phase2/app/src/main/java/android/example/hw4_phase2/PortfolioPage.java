package android.example.hw4_phase2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PortfolioPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.portfolio_page);

        final Button backToMain = findViewById(R.id.portfolio_backButton);
        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMainPage();
            }
        });

        final Button openResume = findViewById(R.id.resumeButton);
        openResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHyperlink();
            }
        });
    }

//    private void setupHyperLink(){
//        TextView linkTextView = findViewById(R.id.resumeHyperlink);
//        linkTextView.setMovementMethod(LinkMovementMethod.getInstance());
//    }

    private void openHyperlink() {
        String url = "https://1drv.ms/w/s!AmpbLN3KhFbmsCrLiO9C_NC0Aax2";
        Intent resumePage = new Intent(Intent.ACTION_VIEW);
        resumePage.setData(Uri.parse(url));
        startActivity(resumePage);
    }

    private void openMainPage() {
        Intent mainPage = new Intent(this, MainActivity.class);
        startActivity(mainPage);
    }

}