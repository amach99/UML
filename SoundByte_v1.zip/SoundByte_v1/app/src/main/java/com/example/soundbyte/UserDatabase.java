package com.example.soundbyte;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class UserDatabase extends SQLiteOpenHelper {

    public static final String USER_DATABASE = "Users.db";
    public static final String USER_TABLE = "user_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "FIRST_NAME";
    public static final String COL_3 = "LAST_NAME";
    public static final String COL_4 = "USERNAME";
    public static final String COL_5 = "EMAIL";
    private static final String COL_6 = "PASSWORD";


    // Constructor
    public UserDatabase(Context context) {
        super(context, USER_DATABASE, null, 1);
        SQLiteDatabase db = this.getWritableDatabase(); // Creates database and table
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + USER_TABLE + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, FIRST_NAME Text, LAST_NAME Text, USERNAME Text, EMAIL Text, PASSWORD Text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        onCreate(db);
    }
}
