package com.example.soundbyte;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class LyricSearch  {

    public static void main(String[] args) throws IOException
    {
        File fileTest = new File("sb_test.txt"); //Creation of File Descriptor for input file
        String[] foundWords = null;

        FileReader read = new FileReader(fileTest); //Creation of File Reader object
        BufferedReader bufferRead = new BufferedReader(read); //Creation of BufferedReader object

        String test;
        String input = "Java"; // Input word to be searched
        int count = 0; //Intialize the word to zero

        while((test = bufferRead.readLine()) != null) //Reading Content from the file
        {
            foundWords = test.split(" "); // Split the word using space
            for (String word : foundWords)
            {
                if(word == input) // Search for the given word
                {
                    count++; //If present increase the count by one
                }
            }
        }

        if(count != 0)
        {
            System.out.println("The given word is present for " +count+ " Times in the file");
        }
        else
        {
            System.out.println("The given word is not present in the file");
        }

        read.close();
    }

}
