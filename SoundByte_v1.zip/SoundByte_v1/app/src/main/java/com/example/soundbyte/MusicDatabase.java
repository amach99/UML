package com.example.soundbyte;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.FileNotFoundException;

public class MusicDatabase {

    // Database Information
    public static final String MUSIC_DATABASE = "Music.db";
    public static final String MUSIC_TABLE = "music_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "SONG_NAME";
    public static final String COL_3 = "ARTIST_NAME";
    public static final String COL_4 = "LYRICS";
    public static final String COL_5 = "IAF";
    public static String[] ALL_KEYS = new String[]{COL_1, COL_2, COL_3, COL_4, COL_5};

    private SQLiteDatabase db;
    private final Context context;

    private DatabaseHelper dbHelper;


    // Constructor
    public MusicDatabase(Context context) {
        this.context = context;
        dbHelper = new DatabaseHelper(context);
    }

    // Open database
    public MusicDatabase open() {
        db = dbHelper.getWritableDatabase();
        return this;
    }

    // Insert a row
    public long insertRow(String id, String songName, String artistName, String lyricFile, String mp3) throws FileNotFoundException {
        ContentValues values = new ContentValues();

        values.put(MusicDatabase.COL_1, id);
        values.put(MusicDatabase.COL_2, songName);
        values.put(MusicDatabase.COL_3, artistName);
        values.put(MusicDatabase.COL_4, lyricFile);
        values.put(MusicDatabase.COL_5, mp3);

        return db.insert(MUSIC_TABLE, null, values);
    }

    // Return all data in the database
    public Cursor getRows() {
        String where = null;
        Cursor c = db.query(true, MUSIC_TABLE, ALL_KEYS, where,
                null, null, null, null, null);
        if (c != null)
            c.moveToFirst();
        return c;
    }

    // Handles Database access
    private class DatabaseHelper extends SQLiteOpenHelper  {

        // Constructor
        public DatabaseHelper(Context context) {
            super(context, MUSIC_DATABASE, null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table " + MUSIC_TABLE + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "SONG_NAME Text, ARTIST_NAME Text, LYRICS Text, MP3 Text)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int i, int i1) {
            db.execSQL("DROP TABLE IF EXISTS " + MUSIC_TABLE);
            onCreate(db);
        }
    }
}



