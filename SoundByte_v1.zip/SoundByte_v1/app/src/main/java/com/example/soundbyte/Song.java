package com.example.soundbyte;

import android.media.SoundPool;

import java.io.File;

public class Song {
    private String songName;
    private String artistName;
    private String lyrics;
    private File lyricsFile;
    private int songID;
    private SoundPool soundPool; // store .mp3 file
    private int sound; // will eventually store sound data from .mp3 file

    public Song(String songName, SoundPool soundPool, int sound) {
        this.songName = songName;
        this.soundPool = soundPool;
        this.sound = sound;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public SoundPool getSoundPool() {
        return soundPool;
    }

    public void setSoundPool(SoundPool soundPool) {
        this.soundPool = soundPool;
    }

    public int getSound() {
        return sound;
    }

    public void setSound(int sound) {
        this.sound = sound;
    }
}
