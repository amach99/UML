package com.example.soundbyte;

import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity
{
   private Song songObj; // create song obj
   private SoundPool songObj_member_sp = songObj.getSoundPool(); // refers to soundPool variable stored in song obj
    private int songObj_member_sound = songObj.getSound();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bottom Navigation default code
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_popular, R.id.navigation_favorites)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);


        // todo: soundPool function starts here! //

        // SoundPool has a new constructor that requires LOLLIPOP
        // if statement checks that BUILD VERSION is >= LOLLIPOP
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            // hit CMD+B or CTRL+B on AudioAttributes.-- to see additional types
//           AudioAttributes audioAttributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();

            AudioAttributes audioAttributes =
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();

            songObj_member_sp = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(audioAttributes).build();

        }
        // use old SoundPool constructor
        else {
            // change max stream argument to allow multiple songs to play at once
            songObj_member_sp = new SoundPool(4, AudioManager.STREAM_MUSIC, 0);
        }
        // load sound into variables
         songObj_member_sound = songObj_member_sp.load(this, R.raw.oh_no_haha, 1); // todo: add music files
    }

//    public void playSound(View view){  // todo: link songObj to xml element here
//        try { // todo: add more sounds here
//            switch (view.getId()){
//                case R.id.button1_Sound:
//                    songObj_member_sp.play(songObj_member_sound,1,1, 0, 0, 1);
//                    break;
//            }
//        }catch (Exception e){
//            Toast.makeText(this, "Error in playSound function", Toast.LENGTH_SHORT).show();
//        }
//    }

    // releases soundPool and frees up used memory
    @Override
    protected void onDestroy() {
        super.onDestroy();
        songObj_member_sp.release();
        songObj_member_sp = null;
    }

}// todo: end of activity!


//    UserDatabase myDatabase;
//    ArrayAdapter<String> adapter;
//    ArrayList<String> lyricList;
//    ListView listView;
//    //String[] lyricList;
//    HomeFragment homeList;
//        myDatabase = new UserDatabase(this); // Calls constructor to create database
//
//        homeList = new HomeFragment();
//        String[] list = homeList.getLyrics();
//        lyricList = new ArrayList<String>();
//
//        for(int i  = 0; i < list.length; i++) {
//            lyricList.add(list[i]);
//        }
//
//        adapter = new ArrayAdapter<String>(
//                this, android.R.layout.simple_list_item_1, lyricList);

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu)
//    {
//        // Inflate menu with items using MenuInflator
//        MenuInflater inflater = getMenuInflater();
//        inflater.inflate(R.menu.search_menu, menu);
//
//        // Associate searchable configuration with the SearchView (Got from Android website)
//        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
//        SearchView searchView = (SearchView) menu.findItem(R.id.app_bar_search).getActionView();
//        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
//
//        // SEARCH LISTENER
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//
//                if (lyricList.contains(query)) {
//                    homeList.getHomeAdapter().getFilter().filter(query);
//                }
//                else {
//                    Toast.makeText(MainActivity.this,
//                            "Not Found", Toast.LENGTH_LONG).show();
//                }
//                return false;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//                homeList.getHomeAdapter().getFilter().filter(newText);
//                return false;
//            }
//        });
//        return super.onCreateOptionsMenu(menu); //true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.navigation_favorites) {
//            return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }
