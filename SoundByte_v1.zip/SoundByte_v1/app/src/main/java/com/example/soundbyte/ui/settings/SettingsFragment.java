package com.example.soundbyte.ui.settings;

import android.app.Activity;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.soundbyte.R;

public class SettingsFragment extends Fragment {

    private SettingsViewModel settingsViewModel;
    ListView listView;
    ArrayAdapter<String> adapter;
    Activity  settingActivity =

    private SoundPool soundPool;
    private int laugh_sound, boom_sound, oh_no_haha_sound, evil_laugh_sound;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        settingsViewModel =
                ViewModelProviders.of(this).get(SettingsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_settings, container, false);

        String[] lyricList = {"CRASH", "BOOM", "SLAM"};
        listView = (ListView) root.findViewById(R.id.favorites_list);

        adapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1, lyricList);
        listView.setAdapter(adapter);

        // SoundPool has a new constructor that requires LOLLIPOP
        // if statement checks that BUILD VERSION is >= LOLLIPOP
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            // hit CMD+B or CTRL+B on AudioAttributes.-- to see additional types
//           AudioAttributes audioAttributes = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();

            AudioAttributes audioAttributes =
                    new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();

            soundPool = new SoundPool.Builder().setMaxStreams(4).setAudioAttributes(audioAttributes).build();

        }
        // use old SoundPool constructor
        else {
            // change max stream argument to allow multiple songs to play at once
            soundPool = new SoundPool(4, AudioManager.STREAM_MUSIC, 0);
        }
        // load sound into variables
        laugh_sound = soundPool.load(this, R.raw.laugh, 1);
        evil_laugh_sound = soundPool.load(this, R.raw.evil_laugh, 1);
        oh_no_haha_sound= soundPool.load(this, R.raw.oh_no_haha, 1);
        boom_sound = soundPool.load(this, R.raw.boom, 1);

        return root;
    }


    public void playSound(View view){
        try {
            switch (view.getId()){
                case R.id.button1_laughSound:
                    soundPool.play(laugh_sound,1,1, 0, 0, 1);
                    break;
                case R.id.button2_evil_laughSound:
                    soundPool.play(evil_laugh_sound,1,1, 0, 0, 1);
                    break;
                case R.id.button3_oh_no_hahaSound:
                    soundPool.play(oh_no_haha_sound,1,1, 0, 0, 1);
                    break;
                case R.id.button4_BoomSound:
                    soundPool.play(boom_sound,1,1, 0, 0, 1);
                    break;
            }
        }catch (Exception e){
            Toast.makeText(this, "Error in playSound function", Toast.LENGTH_SHORT).show();
        }
    }

    // releases soundPool and frees up used memory
    @Override
    public void onDestroy() {
        super.onDestroy();
        songObj_member_sp.release();
        songObj_member_sp = null;
    }

}