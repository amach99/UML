package com.example.soundbyte.ui.home;

import android.media.SoundPool;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.soundbyte.R;
import com.example.soundbyte.Song;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    ListView listView;
    ArrayAdapter<String> stringArrayAdapter;
    ArrayAdapter<Song> songArrayAdapter;

    private Song songObj; // create song obj
    songObj("oh no haha", r)
    private SoundPool songObj_member_sp = songObj.getSoundPool(); // refers to soundPool variable stored in song obj
    private int songObj_member_sound = songObj.getSound();
    private String songName = songObj.getSongName();



    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        String[] lyricList = {songName};
         Song[] songList = {songObj};
        listView = root.findViewById(R.id.home_list);

        songArrayAdapter = new ArrayAdapter<Song>(
                getActivity(), android.R.layout.simple_list_item_1, songList); // populate with (String songName, SoundPool soundPool, int sound)
        listView.setAdapter(songArrayAdapter); // load songs into list

        stringArrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_2, lyricList);
        listView.setAdapter(stringArrayAdapter); // adding text to the list

        // listView item click listener makes each item clickable
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        songObj_member_sp.play(songObj_member_sound, 1, 1, 0, 0, 1);
                        break;
                }
            }
        });

        return root;
    }

    // releases soundPool and frees up used memory
    @Override
    public void onDestroy() {
        super.onDestroy();
        songObj_member_sp.release();
        songObj_member_sp = null;
    }

    public void playSound(View view) {  // todo: link songObj to xml element here
        switch (view.getId()) {
            case R.id.button1_Sound:
                songObj_member_sp.play(songObj_member_sound, 1, 1, 0, 0, 1);
                break;
        }
    }

    public ArrayAdapter<String> getHomeAdapter() {
        String[] lyricList = this.getLyrics();
        stringArrayAdapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_list_item_1, lyricList);
        return stringArrayAdapter;
    }

    public String[] getLyrics() {
        String[] list = {"CRASH", "BOOM", "SLAM"};
        return list;
    }
}